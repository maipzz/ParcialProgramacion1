package com.parcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialProgramacion12ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.parcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParcialProgramacion12Application {

	public static void main(String[] args) {
		SpringApplication.run(ParcialProgramacion12Application.class, args);
	}

}
